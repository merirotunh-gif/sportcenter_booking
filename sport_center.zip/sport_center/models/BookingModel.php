<?php
class BookingModel {
    private $conn;
    private $table = "bookings";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAllBookings() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach($rows as &$row) {
            $row['slots'] = json_decode($row['slots'], true);
        }
        return $rows;
    }

    public function getOccupiedSlots() {
        $query = "SELECT field_id, slots FROM " . $this->table . " WHERE status = 'confirmed'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $occupied = [];
        foreach($results as $row) {
            $fieldId = $row['field_id'];
            $slots = json_decode($row['slots'], true);
            if(!isset($occupied[$fieldId])) {
                $occupied[$fieldId] = [];
            }
            if(is_array($slots)) {
                $occupied[$fieldId] = array_merge($occupied[$fieldId], $slots);
            }
        }
        return $occupied;
    }

    public function createBooking($data) {
        $query = "INSERT INTO " . $this->table . " (code, name, team, field_id, field_name, date, slots, total, status) VALUES (:code, :name, :team, :field_id, :field_name, :date, :slots, :total, :status)";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":code", $data['code']);
        $stmt->bindParam(":name", $data['name']);
        $stmt->bindParam(":team", $data['team']);
        $stmt->bindParam(":field_id", $data['field_id']);
        $stmt->bindParam(":field_name", $data['field_name']);
        $stmt->bindParam(":date", $data['date']);
        $slotsJson = json_encode($data['slots']);
        $stmt->bindParam(":slots", $slotsJson);
        $stmt->bindParam(":total", $data['total']);
        $stmt->bindParam(":status", $data['status']);

        return $stmt->execute();
    }

    public function cancelBooking($code) {
        $query = "DELETE FROM " . $this->table . " WHERE code = :code";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":code", $code);
        return $stmt->execute();
    }
}
?>