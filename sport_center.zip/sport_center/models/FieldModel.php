<?php
class FieldModel {
    private $conn;
    private $table = "fields";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAllFields() {
        $query = "SELECT * FROM " . $this->table;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>