<?php
session_start();
require_once 'config/database.php';
require_once 'models/FieldModel.php';
require_once 'models/BookingModel.php';
require_once 'models/AdminModel.php';

class BookingController {
    private $db;
    private $fieldModel;
    private $bookingModel;
    private $adminModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->fieldModel = new FieldModel($this->db);
        $this->bookingModel = new BookingModel($this->db);
        $this->adminModel = new AdminModel($this->db);
    }

    public function handleRequest() {
        $action = $_GET['action'] ?? $_POST['action'] ?? '';

        if ($action === 'login') {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $username = trim($_POST['username']);
                $password = trim($_POST['password']);
                $admin = $this->adminModel->login($username, $password);

                if ($admin) {
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_username'] = $admin['username'];
                    $_SESSION['admin_name'] = $admin['nama_lengkap'];
                    header('Location: index.php');
                    exit;
                } else {
                    $error = "Username atau password salah!";
                    include 'views/login.php';
                    return;
                }
            } else {
                include 'views/login.php';
                return;
            }
        }

        if ($action === 'logout') {
            unset($_SESSION['admin_logged_in']);
            unset($_SESSION['admin_username']);
            unset($_SESSION['admin_name']);
            session_destroy();
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($action === 'store') {
                $code = 'SC-' . mt_rand(1000, 9999);
                $fieldObj = null;
                $fields = $this->fieldModel->getAllFields();
                foreach($fields as $f) {
                    if($f['id'] === $_POST['field_id']) {
                        $fieldObj = $f;
                        break;
                    }
                }

                $data = [
                    'code' => $code,
                    'name' => $_POST['name'],
                    'team' => $_POST['team'] ?: '-',
                    'field_id' => $_POST['field_id'],
                    'field_name' => $fieldObj ? $fieldObj['name'] : 'Lapangan',
                    'date' => $_POST['date'],
                    'slots' => $_POST['slots'] ?? [],
                    'total' => (int)$_POST['total'],
                    'status' => 'confirmed'
                ];

                $success = $this->bookingModel->createBooking($data);
                header('Content-Type: application/json');
                echo json_encode(['success' => $success, 'data' => $data]);
                exit;
            }

            if ($action === 'cancel') {
                if (!isset($_SESSION['admin_logged_in'])) {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                    exit;
                }

                $code = $_POST['code'] ?? '';
                $success = $this->bookingModel->cancelBooking($code);
                header('Content-Type: application/json');
                echo json_encode(['success' => $success]);
                exit;
            }
        }

        $fieldsData = $this->fieldModel->getAllFields();
        $activeBookings = $this->bookingModel->getAllBookings();
        $occupiedSlotsDatabase = $this->bookingModel->getOccupiedSlots();
        $isAdmin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

        include 'views/sport_center.php';
    }
}
?>