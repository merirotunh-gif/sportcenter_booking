<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SportCenter Booking - Reservasi Lapangan Olahraga</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        navy: { 900: '#070c1a', 800: '#0b132b', 700: '#1c2541', 600: '#2a365c' },
                        neon: { 400: '#38ef7d', 500: '#00ff87', 600: '#00cc6a' }
                    },
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    boxShadow: {
                        'neon-glow': '0 0 20px rgba(0, 255, 135, 0.35)',
                        'neon-glow-lg': '0 0 35px rgba(0, 255, 135, 0.5)',
                        'card-glow': '0 8px 32px 0 rgba(0, 0, 0, 0.37)'
                    }
                }
            }
        }
    </script>

    <style>
        body { font-family: 'Inter', sans-serif; background-color: #070c1a; color: #f1f5f9; overflow-x: hidden; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: #0b132b; }
        ::-webkit-scrollbar-thumb { background: #1c2541; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #00ff87; }
        .glass-card { background: rgba(28, 37, 65, 0.65); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.08); }
        .glass-card-hover { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .glass-card-hover:hover { transform: translateY(-4px); border-color: rgba(0, 255, 135, 0.4); box-shadow: 0 10px 30px -10px rgba(0, 255, 135, 0.2); }
        .slot-btn { transition: all 0.2s ease-in-out; }
        @keyframes pulseGlow { 0%, 100% { box-shadow: 0 0 15px rgba(0, 255, 135, 0.4); } 50% { box-shadow: 0 0 25px rgba(0, 255, 135, 0.8); } }
        .animate-pulse-glow { animation: pulseGlow 2s infinite; }
        #confetti-canvas { position: fixed; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 100; }
    </style>
</head>
<body class="min-h-screen flex flex-col justify-between selection:bg-neon-500 selection:text-navy-900">

    <canvas id="confetti-canvas"></canvas>

    <header class="sticky top-0 z-40 bg-navy-800/90 backdrop-blur-md border-b border-white/10 px-4 lg:px-8 py-3 transition-all duration-300">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <a href="#" class="flex items-center gap-3 group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-neon-500 to-neon-400 flex items-center justify-center text-navy-900 font-extrabold text-xl shadow-neon-glow group-hover:scale-105 transition-transform">
                    <i class="fa-solid fa-bolt text-navy-900"></i>
                </div>
                <div>
                    <span class="text-xl font-black tracking-wider uppercase text-white">SPORT<span class="text-neon-500">CENTER</span></span>
                    <span class="block text-[10px] tracking-widest text-gray-400 font-semibold -mt-1 uppercase">BOOKING SYSTEM</span>
                </div>
            </a>

            <nav class="hidden md:flex items-center gap-8 font-medium text-sm">
                <a href="#katalog" class="text-gray-300 hover:text-neon-500 transition-colors flex items-center gap-2"><i class="fa-solid fa-layer-group text-xs text-neon-500"></i> Katalog Lapangan</a>
                <a href="#reservasi" class="text-gray-300 hover:text-neon-500 transition-colors flex items-center gap-2"><i class="fa-solid fa-calendar-check text-xs text-neon-500"></i> Form Booking</a>
                <a href="#riwayat" class="text-gray-300 hover:text-neon-500 transition-colors flex items-center gap-2"><i class="fa-solid fa-clock-rotate-left text-xs text-neon-500"></i> Riwayat Pesanan</a>
                <a href="#fasilitas" class="text-gray-300 hover:text-neon-500 transition-colors flex items-center gap-2"><i class="fa-solid fa-shield-halved text-xs text-neon-500"></i> Keunggulan</a>
            </nav>

            <div class="flex items-center gap-3">
                <a href="#reservasi" class="bg-neon-500 hover:bg-neon-400 text-navy-900 font-bold px-4 py-2 rounded-xl text-xs sm:text-sm transition-all shadow-neon-glow hover:shadow-neon-glow-lg flex items-center gap-2">
                    <i class="fa-solid fa-plus-circle"></i>
                    <span>Sewa Sekarang</span>
                </a>

                <?php if(isset($isAdmin) && $isAdmin): ?>
                    <div class="flex items-center gap-2 bg-navy-700/80 border border-neon-500/40 px-3 py-1.5 rounded-xl">
                        <span class="w-2 h-2 rounded-full bg-neon-500 animate-pulse"></span>
                        <span class="text-xs font-bold text-neon-400 hidden sm:inline">Admin: <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                        <a href="index.php?action=logout" class="bg-red-500/20 hover:bg-red-500/40 text-red-300 px-2 py-1 rounded-lg text-xs font-bold transition-colors ml-1" title="Logout">
                            <i class="fa-solid fa-right-from-bracket"></i>
                        </a>
                    </div>
                <?php else: ?>
                    <a href="index.php?action=login" class="bg-navy-700 hover:bg-navy-600 border border-white/10 text-gray-300 hover:text-white px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5">
                        <i class="fa-solid fa-user-shield text-neon-500"></i>
                        <span class="hidden sm:inline">Admin Login</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-16">

        <section class="relative rounded-3xl overflow-hidden glass-card p-6 sm:p-10 border border-white/10 bg-gradient-to-r from-navy-800 via-navy-700 to-navy-800 shadow-2xl">
            <div class="absolute -top-24 -right-24 w-96 h-96 bg-neon-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

            <div class="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div class="lg:col-span-7 space-y-6">
                    <div class="inline-flex items-center gap-2 bg-neon-500/10 border border-neon-500/30 text-neon-500 text-xs font-semibold px-3.5 py-1.5 rounded-full">
                        <span class="w-2 h-2 rounded-full bg-neon-500 animate-ping"></span>
                        Platform Booking Lapangan Terpercaya & Real-Time
                    </div>
                    <h1 class="text-3xl sm:text-5xl font-black text-white leading-tight tracking-tight">
                        Main Lebih Praktis, <br/>
                        <span class="text-transparent bg-clip-text bg-gradient-to-r from-neon-400 to-neon-500">
                            Booking Lapangan Impian
                        </span> Dalam Detik!
                    </h1>
                    <p class="text-gray-300 text-sm sm:text-base leading-relaxed max-w-2xl">
                        Akses fleksibel ke berbagai lapangan olahraga premium standar internasional. Cek ketersediaan jam secara langsung, hitung biaya transparan tanpa biaya tersembunyi, dan amankan slot tim kamu sekarang.
                    </p>

                    <div class="grid grid-cols-3 gap-4 pt-2 border-t border-white/10">
                        <div>
                            <span class="text-2xl font-extrabold text-neon-500 block">4+</span>
                            <span class="text-xs text-gray-400">Jenis Lapangan</span>
                        </div>
                        <div>
                            <span class="text-2xl font-extrabold text-white block">100%</span>
                            <span class="text-xs text-gray-400">Real-Time Schedule</span>
                        </div>
                        <div>
                            <span class="text-2xl font-extrabold text-neon-500 block">4.9/5</span>
                            <span class="text-xs text-gray-400">Kepuasan Atlet</span>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-5">
                    <div class="p-6 rounded-2xl bg-navy-900/80 border border-white/10 shadow-xl space-y-4">
                        <div class="flex items-center justify-between pb-3 border-b border-white/10">
                            <span class="text-sm font-semibold text-gray-300 flex items-center gap-2">
                                <i class="fa-solid fa-circle-dot text-neon-500"></i> Status Operasional
                            </span>
                            <span class="bg-neon-500/20 text-neon-400 text-xs px-2.5 py-1 rounded-full font-bold">BUKA HARI INI</span>
                        </div>
                        <div class="space-y-3 text-xs sm:text-sm text-gray-300">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400"><i class="fa-regular fa-clock mr-1.5 text-neon-500"></i> Jam Operasional:</span>
                                <span class="font-semibold text-white">07:00 - 23:00 WIB</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400"><i class="fa-solid fa-wifi mr-1.5 text-neon-500"></i> Fasilitas Umum:</span>
                                <span class="font-semibold text-white">Free WiFi, Shower, Kantin</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400"><i class="fa-solid fa-location-dot mr-1.5 text-neon-500"></i> Lokasi Arena:</span>
                                <span class="font-semibold text-white">SportCenter Complex Kav. 88</span>
                            </div>
                        </div>
                        <a href="#reservasi" class="block text-center w-full bg-navy-700 hover:bg-navy-600 border border-neon-500/40 text-neon-400 font-bold py-2.5 rounded-xl text-xs transition-all">
                            Cek Jadwal Lapangan Hari Ini &rarr;
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- SECTION 1: Catalog -->
        <section id="katalog" class="space-y-6 scroll-mt-24">
            <div class="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                    <span class="text-neon-500 text-xs font-bold tracking-widest uppercase block mb-1">Pilihan Arena Terbaik</span>
                    <h2 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
                        <i class="fa-solid fa-trophy text-neon-500"></i> Katalog Lapangan & Spesifikasi
                    </h2>
                </div>
                <div class="flex flex-wrap gap-2" id="catalog-filter">
                    <button onclick="filterCatalog('all')" class="filter-btn active bg-neon-500 text-navy-900 text-xs font-bold px-4 py-2 rounded-xl transition-all">Semua Lapangan</button>
                    <button onclick="filterCatalog('futsal')" class="filter-btn bg-navy-700 hover:bg-navy-600 text-gray-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">Futsal</button>
                    <button onclick="filterCatalog('basket')" class="filter-btn bg-navy-700 hover:bg-navy-600 text-gray-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">Basket</button>
                    <button onclick="filterCatalog('badminton')" class="filter-btn bg-navy-700 hover:bg-navy-600 text-gray-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">Badminton</button>
                    <button onclick="filterCatalog('tenis')" class="filter-btn bg-navy-700 hover:bg-navy-600 text-gray-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">Tenis</button>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" id="fields-grid"></div>
        </section>

        <!-- SECTION 2: Booking Form -->
        <section id="reservasi" class="scroll-mt-24">
            <div class="mb-6">
                <span class="text-neon-500 text-xs font-bold tracking-widest uppercase block mb-1">Reservasi Cepat & Mudah</span>
                <h2 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
                    <i class="fa-solid fa-calendar-plus text-neon-500"></i> Form Pemesanan Interaktif
                </h2>
                <p class="text-gray-400 text-xs sm:text-sm">Pilih jenis lapangan, tentukan tanggal, lalu klik slot jam yang masih tersedia.</p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div class="lg:col-span-8 space-y-6">
                    <div class="glass-card p-6 rounded-2xl space-y-6 border border-white/10">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
                                    <span class="text-neon-500 font-black">1.</span> Pilih Lapangan
                                </label>
                                <div class="relative">
                                    <select id="field-select" onchange="handleFieldChange()" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-neon-500 appearance-none font-medium"></select>
                                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-neon-500">
                                        <i class="fa-solid fa-chevron-down"></i>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label class="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
                                    <span class="text-neon-500 font-black">2.</span> Pilih Tanggal Main
                                </label>
                                <input type="date" id="booking-date" onchange="handleDateChange()" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-neon-500 font-medium">
                            </div>
                        </div>

                        <div class="pt-2 border-t border-white/10 space-y-4">
                            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                                <div>
                                    <label class="block text-xs font-bold uppercase tracking-wider text-gray-300">
                                        <span class="text-neon-500 font-black">3.</span> Pilih Slot Jam Bermain
                                    </label>
                                    <p class="text-[11px] text-gray-400">Kamu bisa memilih lebih dari 1 slot jam sekaligus.</p>
                                </div>

                                <div class="flex items-center gap-3 text-[11px]">
                                    <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-md bg-navy-900 border border-neon-500/50"></span><span class="text-gray-300">Tersedia</span></div>
                                    <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-md bg-neon-500 shadow-neon-glow"></span><span class="text-white font-bold">Dipilih</span></div>
                                    <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded-md bg-red-900/60 border border-red-500/40"></span><span class="text-gray-400">Terisi</span></div>
                                </div>
                            </div>

                            <div class="flex gap-2 border-b border-white/10 pb-2">
                                <button type="button" onclick="filterSlotPeriod('all')" class="slot-tab active-tab text-xs font-semibold px-3 py-1.5 rounded-lg bg-navy-700 text-neon-400">Semua Jam</button>
                                <button type="button" onclick="filterSlotPeriod('pagi')" class="slot-tab text-xs font-semibold px-3 py-1.5 rounded-lg text-gray-400 hover:text-white">Pagi (07-12)</button>
                                <button type="button" onclick="filterSlotPeriod('siang')" class="slot-tab text-xs font-semibold px-3 py-1.5 rounded-lg text-gray-400 hover:text-white">Siang (12-17)</button>
                                <button type="button" onclick="filterSlotPeriod('malam')" class="slot-tab text-xs font-semibold px-3 py-1.5 rounded-lg text-gray-400 hover:text-white">Malam (17-23)</button>
                            </div>

                            <div id="slots-container" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 pt-2"></div>
                        </div>

                        <div class="pt-4 border-t border-white/10 space-y-3">
                            <label class="block text-xs font-bold uppercase tracking-wider text-gray-300">Tambahan Perlengkapan (Opsional)</label>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <label class="flex items-center justify-between p-3 rounded-xl bg-navy-900/60 border border-white/10 cursor-pointer hover:border-neon-500/50 transition-colors">
                                    <div class="flex items-center gap-2">
                                        <input type="checkbox" id="extra-referee" onchange="calculateTotal()" class="w-4 h-4 accent-neon-500 rounded">
                                        <span class="text-xs text-gray-200">Jasa Wasit Resmi</span>
                                    </div>
                                    <span class="text-xs font-bold text-neon-500">+Rp 50.000 / jam</span>
                                </label>
                                <label class="flex items-center justify-between p-3 rounded-xl bg-navy-900/60 border border-white/10 cursor-pointer hover:border-neon-500/50 transition-colors">
                                    <div class="flex items-center gap-2">
                                        <input type="checkbox" id="extra-balls" onchange="calculateTotal()" class="w-4 h-4 accent-neon-500 rounded">
                                        <span class="text-xs text-gray-200">Sewa Bola Tambahan (3x)</span>
                                    </div>
                                    <span class="text-xs font-bold text-neon-500">+Rp 20.000 / flat</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="glass-card p-6 rounded-2xl space-y-4 border border-white/10">
                        <h3 class="text-sm font-bold uppercase tracking-wider text-gray-200 flex items-center gap-2">
                            <span class="text-neon-500 font-black">4.</span> Informasi Pemesan / Tim Olahraga
                        </h3>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-medium text-gray-400 mb-1">Nama Lengkap *</label>
                                <input type="text" id="cust-name" placeholder="Contoh: Budi Pratama" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-neon-500">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-400 mb-1">Nomor WhatsApp / HP *</label>
                                <input type="tel" id="cust-phone" placeholder="081234567890" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-neon-500">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-400 mb-1">Nama Tim / Klub (Opsional)</label>
                                <input type="text" id="cust-team" placeholder="Contoh: Thunder FC" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-neon-500">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-400 mb-1">Metode Pembayaran</label>
                                <select id="cust-payment" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-neon-500">
                                    <option value="QRIS / E-Wallet">QRIS / E-Wallet (BCA, GoPay, OVO)</option>
                                    <option value="Transfer Bank BCA">Transfer Bank BCA</option>
                                    <option value="Bayar di Kasir (DP 50%)">Bayar di Kasir (DP 50%)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-4 sticky top-24">
                    <div class="glass-card p-6 rounded-2xl space-y-6 border border-neon-500/30 shadow-neon-glow">
                        <div class="flex items-center justify-between pb-3 border-b border-white/10">
                            <h3 class="text-base font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-receipt text-neon-500"></i> Ringkasan Biaya
                            </h3>
                            <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-neon-500/20 text-neon-400">Live Updating</span>
                        </div>

                        <div class="space-y-3 text-xs sm:text-sm">
                            <div class="flex justify-between items-start"><span class="text-gray-400">Lapangan:</span><span id="summary-field-name" class="font-bold text-white text-right">Futsal Synthetic A</span></div>
                            <div class="flex justify-between items-start"><span class="text-gray-400">Tarif Dasar:</span><span id="summary-field-rate" class="font-semibold text-gray-200">Rp 150.000 / jam</span></div>
                            <div class="flex justify-between items-start"><span class="text-gray-400">Tanggal Main:</span><span id="summary-date" class="font-semibold text-white">Hari ini</span></div>
                            <div class="flex justify-between items-start"><span class="text-gray-400">Slot Jam Dipilih:</span><span id="summary-slots-count" class="font-bold text-neon-500">0 Jam</span></div>

                            <div id="summary-slots-list" class="flex flex-wrap gap-1.5 py-1 min-h-[30px]"><span class="text-[11px] text-gray-500 italic">Belum ada slot jam dipilih</span></div>

                            <div id="summary-extras-row" class="hidden space-y-1 pt-2 border-t border-white/5 text-xs">
                                <div class="flex justify-between text-gray-300"><span>Tambahan Wasit:</span><span id="summary-referee-cost">Rp 0</span></div>
                                <div class="flex justify-between text-gray-300"><span>Tambahan Bola:</span><span id="summary-balls-cost">Rp 0</span></div>
                            </div>

                            <div class="pt-4 border-t border-white/10 space-y-1">
                                <div class="flex justify-between items-center"><span class="text-xs uppercase font-bold tracking-wider text-gray-400">Total Pembayaran</span><span class="text-xs text-neon-500 font-medium">Termasuk Pajak</span></div>
                                <div class="text-right"><span id="summary-total-price" class="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-neon-400 to-neon-500">Rp 0</span></div>
                            </div>
                        </div>

                        <button type="button" onclick="submitBooking()" class="w-full bg-gradient-to-r from-neon-500 to-neon-400 hover:from-neon-400 hover:to-neon-500 text-navy-900 font-extrabold py-3.5 px-4 rounded-xl text-sm transition-all shadow-neon-glow hover:shadow-neon-glow-lg flex items-center justify-center gap-2 transform active:scale-95">
                            <i class="fa-solid fa-circle-check text-lg"></i>
                            <span>KONFIRMASI BOOKING NOW</span>
                        </button>

                        <div class="text-[11px] text-gray-400 text-center flex items-center justify-center gap-1">
                            <i class="fa-solid fa-lock text-neon-500"></i> Transaksi terenkripsi aman & garansi slot
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- SECTION 3: History Table -->
        <section id="riwayat" class="space-y-6 scroll-mt-24">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <span class="text-neon-500 text-xs font-bold tracking-widest uppercase block mb-1">Daftar Reservasi Anda</span>
                    <h2 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
                        <i class="fa-solid fa-list-check text-neon-500"></i> Riwayat & Booking Aktif
                    </h2>
                </div>
                <div class="flex gap-2">
                    <button onclick="filterHistory('all')" class="hist-filter active bg-navy-700 text-neon-400 text-xs font-bold px-3 py-1.5 rounded-lg border border-white/10">Semua</button>
                    <button onclick="filterHistory('confirmed')" class="hist-filter text-gray-400 hover:text-white text-xs font-bold px-3 py-1.5 rounded-lg border border-white/10">Terkonfirmasi</button>
                    <button onclick="filterHistory('completed')" class="hist-filter text-gray-400 hover:text-white text-xs font-bold px-3 py-1.5 rounded-lg border border-white/10">Selesai</button>
                </div>
            </div>

            <div class="glass-card rounded-2xl overflow-hidden border border-white/10">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-navy-900/80 text-neon-500 text-xs uppercase tracking-wider font-extrabold border-b border-white/10">
                                <th class="p-4">Kode Booking</th>
                                <th class="p-4">Pemesan / Tim</th>
                                <th class="p-4">Lapangan</th>
                                <th class="p-4">Tanggal & Jam</th>
                                <th class="p-4">Total Biaya</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="booking-history-rows" class="divide-y divide-white/5 text-xs sm:text-sm"></tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- SECTION 4: Features -->
        <section id="fasilitas" class="grid grid-cols-1 md:grid-cols-3 gap-6 scroll-mt-24">
            <div class="glass-card glass-card-hover p-6 rounded-2xl space-y-3">
                <div class="w-12 h-12 rounded-xl bg-neon-500/20 text-neon-500 flex items-center justify-center text-xl font-bold"><i class="fa-solid fa-shield-halved"></i></div>
                <h3 class="text-base font-bold text-white">Standar Internasional</h3>
                <p class="text-xs text-gray-300 leading-relaxed">Rumput sintetis interlock, parket kayu jati asli, dan karpet vinyl bersertifikat resmi untuk keamanan maksimal sendi & otot.</p>
            </div>
            <div class="glass-card glass-card-hover p-6 rounded-2xl space-y-3">
                <div class="w-12 h-12 rounded-xl bg-neon-500/20 text-neon-500 flex items-center justify-center text-xl font-bold"><i class="fa-solid fa-lightbulb"></i></div>
                <h3 class="text-base font-bold text-white">Pencahayaan LED HD Stadium</h3>
                <p class="text-xs text-gray-300 leading-relaxed">Pencahayaan terang bebas bayangan berdaya tinggi (1000 Lux), memberikan visibilitas optimal untuk pertandingan malam hari.</p>
            </div>
            <div class="glass-card glass-card-hover p-6 rounded-2xl space-y-3">
                <div class="w-12 h-12 rounded-xl bg-neon-500/20 text-neon-500 flex items-center justify-center text-xl font-bold"><i class="fa-solid fa-shower"></i></div>
                <h3 class="text-base font-bold text-white">Ruang Ganti & Shower</h3>
                <p class="text-xs text-gray-300 leading-relaxed">Fasilitas shower air hangat, loker pribadi gratis, dan area kantin makanan sehat yang bersih serta nyaman untuk tim.</p>
            </div>
        </section>

    </main>

    <footer class="bg-navy-900 border-t border-white/10 py-10 px-4 mt-16 text-xs text-gray-400">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg bg-neon-500 flex items-center justify-center text-navy-900 font-extrabold text-lg"><i class="fa-solid fa-bolt"></i></div>
                <div><span class="font-bold text-white uppercase text-sm tracking-wider">SportCenter Booking</span><p class="text-[11px] text-gray-500">Sistem Reservasi Lapangan Olahraga Terpadu © 2026</p></div>
            </div>
            <div class="flex items-center gap-6"><a href="#" class="hover:text-neon-500 transition-colors">Syarat & Ketentuan</a><a href="#" class="hover:text-neon-500 transition-colors">Kebijakan Privasi</a><a href="#" class="hover:text-neon-500 transition-colors">Bantuan WhatsApp</a></div>
            <div class="flex items-center gap-3">
                <a href="#" class="w-8 h-8 rounded-full bg-navy-800 hover:bg-neon-500 hover:text-navy-900 flex items-center justify-center transition-all"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="w-8 h-8 rounded-full bg-navy-800 hover:bg-neon-500 hover:text-navy-900 flex items-center justify-center transition-all"><i class="fa-brands fa-whatsapp"></i></a>
                <a href="#" class="w-8 h-8 rounded-full bg-navy-800 hover:bg-neon-500 hover:text-navy-900 flex items-center justify-center transition-all"><i class="fa-solid fa-envelope"></i></a>
            </div>
        </div>
    </footer>

    <div id="booking-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md hidden opacity-0 transition-opacity duration-300 p-4">
        <div class="glass-card bg-navy-800 max-w-lg w-full rounded-3xl p-6 sm:p-8 border border-neon-500/50 shadow-neon-glow relative transform scale-95 transition-transform duration-300 overflow-hidden" id="modal-content">
            <button onclick="closeModal()" class="absolute top-4 right-4 text-gray-400 hover:text-white w-8 h-8 rounded-full bg-navy-900 flex items-center justify-center border border-white/10"><i class="fa-solid fa-xmark"></i></button>
            <div class="text-center space-y-3 pb-4 border-b border-white/10">
                <div class="w-16 h-16 bg-neon-500/20 text-neon-500 rounded-full flex items-center justify-center mx-auto text-3xl animate-bounce"><i class="fa-solid fa-circle-check"></i></div>
                <h3 class="text-2xl font-black text-white">RESERVASI BERHASIL!</h3>
                <p class="text-xs text-gray-300">Bukti konfirmasi pemesanan telah diterbitkan. Silakan simpan nota ini.</p>
            </div>
            <div class="py-4 space-y-3 text-xs sm:text-sm font-mono text-gray-200" id="receipt-details">
                <div class="flex justify-between border-b border-white/5 pb-2"><span class="text-gray-400">Kode Transaksi:</span><span id="rec-code" class="text-neon-400 font-bold">SC-2026-8812</span></div>
                <div class="flex justify-between"><span class="text-gray-400">Pemesan:</span><span id="rec-name" class="font-semibold text-white">Budi Pratama</span></div>
                <div class="flex justify-between"><span class="text-gray-400">Klub / Tim:</span><span id="rec-team" class="font-semibold text-white">Thunder FC</span></div>
                <div class="flex justify-between"><span class="text-gray-400">Lapangan:</span><span id="rec-field" class="font-semibold text-white">Futsal Synthetic A</span></div>
                <div class="flex justify-between"><span class="text-gray-400">Tanggal:</span><span id="rec-date" class="font-semibold text-white">2026-10-21</span></div>
                <div class="flex justify-between"><span class="text-gray-400">Slot Jam:</span><span id="rec-slots" class="font-semibold text-neon-400 text-right">18:00, 19:00</span></div>
                <div class="flex justify-between border-t border-white/10 pt-2 font-sans font-bold"><span class="text-gray-300">Total Biaya:</span><span id="rec-total" class="text-lg text-neon-500">Rp 300.000</span></div>
            </div>
            <div class="flex gap-3 pt-2">
                <button onclick="window.print()" class="flex-1 bg-navy-700 hover:bg-navy-600 border border-white/20 text-white font-bold py-3 rounded-xl text-xs transition-colors flex items-center justify-center gap-2"><i class="fa-solid fa-print"></i> Cetak Bukti</button>
                <button onclick="closeModal()" class="flex-1 bg-neon-500 hover:bg-neon-400 text-navy-900 font-extrabold py-3 rounded-xl text-xs transition-colors shadow-neon-glow">Selesai & Lihat Riwayat</button>
            </div>
        </div>
    </div>

    <div id="toast-container" class="fixed bottom-5 right-5 z-50 space-y-2 pointer-events-none"></div>

    <script>
        const fieldsData = <?php echo json_encode($fieldsData); ?>;
        const occupiedSlotsDatabase = <?php echo json_encode($occupiedSlotsDatabase); ?>;
        let activeBookings = <?php echo json_encode($activeBookings); ?>;
        const isAdminLoggedIn = <?php echo (isset($isAdmin) && $isAdmin) ? 'true' : 'false'; ?>;

        const timeSlotsMaster = [
            { id: 'slot-07', time: '07:00 - 08:00', period: 'pagi' },
            { id: 'slot-08', time: '08:00 - 09:00', period: 'pagi' },
            { id: 'slot-09', time: '09:00 - 10:00', period: 'pagi' },
            { id: 'slot-10', time: '10:00 - 11:00', period: 'pagi' },
            { id: 'slot-11', time: '11:00 - 12:00', period: 'pagi' },
            { id: 'slot-12', time: '12:00 - 13:00', period: 'siang' },
            { id: 'slot-13', time: '13:00 - 14:00', period: 'siang' },
            { id: 'slot-14', time: '14:00 - 15:00', period: 'siang' },
            { id: 'slot-15', time: '15:00 - 16:00', period: 'siang' },
            { id: 'slot-16', time: '16:00 - 17:00', period: 'siang' },
            { id: 'slot-17', time: '17:00 - 18:00', period: 'malam' },
            { id: 'slot-18', time: '18:00 - 19:00', period: 'malam' },
            { id: 'slot-19', time: '19:00 - 20:00', period: 'malam' },
            { id: 'slot-20', time: '20:00 - 21:00', period: 'malam' },
            { id: 'slot-21', time: '21:00 - 22:00', period: 'malam' }
        ];

        let selectedFieldId = fieldsData.length > 0 ? fieldsData[0].id : 'futsal-a';
        let selectedSlots = [];
        let selectedPeriodFilter = 'all';

        window.addEventListener('DOMContentLoaded', () => {
            const dateInput = document.getElementById('booking-date');
            const today = new Date().toISOString().split('T')[0];
            dateInput.min = today;
            dateInput.value = today;

            renderCatalog('all');
            populateFieldDropdown();
            renderSlots();
            calculateTotal();
            renderHistoryTable('all');
        });

        function renderCatalog(filter) {
            const container = document.getElementById('fields-grid');
            container.innerHTML = '';
            const filtered = filter === 'all' ? fieldsData : fieldsData.filter(f => f.category === filter);

            filtered.forEach(field => {
                const card = document.createElement('div');
                card.className = 'glass-card glass-card-hover rounded-2xl overflow-hidden flex flex-col justify-between border border-white/10 group';
                card.innerHTML = `
                    <div>
                        <div class="relative h-48 overflow-hidden">
                            <img src="${field.image}" alt="${field.name}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                            <div class="absolute top-3 right-3 bg-navy-900/95 backdrop-blur-md px-2.5 py-1 rounded-lg text-xs font-extrabold text-neon-400 border border-white/10"><i class="fa-solid fa-star text-amber-400 mr-1"></i>${field.rating}</div>
                            <div class="absolute bottom-3 left-3 bg-navy-900/90 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-bold text-white border border-white/10">${field.type}</div>
                        </div>
                        <div class="p-5 space-y-3">
                            <h3 class="text-lg font-extrabold text-white group-hover:text-neon-400 transition-colors">${field.name}</h3>
                            <p class="text-xs text-gray-300 font-medium">${field.surface}</p>
                            <div class="space-y-1.5 pt-2 border-t border-white/10 text-[11px] text-gray-400">
                                <p><i class="fa-solid fa-ruler-combined text-neon-500 mr-1.5"></i>${field.specs}</p>
                                <p><i class="fa-solid fa-check-circle text-neon-500 mr-1.5"></i>${field.facilities}</p>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 pt-0 flex items-center justify-between border-t border-white/5 mt-2">
                        <div>
                            <span class="text-[10px] text-gray-400 block uppercase">Tarif Sewa</span>
                            <span class="text-lg font-black text-neon-500">Rp ${parseInt(field.rate).toLocaleString('id-ID')}</span>
                            <span class="text-[10px] text-gray-400">/ jam</span>
                        </div>
                        <button onclick="selectAndScrollToBooking('${field.id}')" class="bg-neon-500 hover:bg-neon-400 text-navy-900 font-extrabold px-4 py-2 rounded-xl text-xs transition-all shadow-neon-glow flex items-center gap-1.5">
                            Pilih <i class="fa-solid fa-arrow-right text-[10px]"></i>
                        </button>
                    </div>
                `;
                container.appendChild(card);
            });
        }

        function filterCatalog(category) {
            document.querySelectorAll('#catalog-filter button').forEach(btn => {
                btn.classList.remove('bg-neon-500', 'text-navy-900');
                btn.classList.add('bg-navy-700', 'text-gray-300');
            });
            event.target.classList.remove('bg-navy-700', 'text-gray-300');
            event.target.classList.add('bg-neon-500', 'text-navy-900');
            renderCatalog(category);
        }

        function populateFieldDropdown() {
            const select = document.getElementById('field-select');
            select.innerHTML = '';
            fieldsData.forEach(field => {
                const opt = document.createElement('option');
                opt.value = field.id;
                opt.textContent = `${field.name} - (Rp ${parseInt(field.rate).toLocaleString('id-ID')}/jam)`;
                select.appendChild(opt);
            });
        }

        function selectAndScrollToBooking(fieldId) {
            selectedFieldId = fieldId;
            document.getElementById('field-select').value = fieldId;
            selectedSlots = [];
            renderSlots();
            calculateTotal();
            document.getElementById('reservasi').scrollIntoView({ behavior: 'smooth' });
            showToast('Lapangan dipilih. Silakan tentukan slot jam main!');
        }

        function handleFieldChange() {
            selectedFieldId = document.getElementById('field-select').value;
            selectedSlots = [];
            renderSlots();
            calculateTotal();
        }

        function handleDateChange() {
            selectedSlots = [];
            renderSlots();
            calculateTotal();
            showToast('Tanggal diperbarui. Silakan pilih jam.');
        }

        function filterSlotPeriod(period) {
            selectedPeriodFilter = period;
            document.querySelectorAll('.slot-tab').forEach(tab => {
                tab.classList.remove('bg-navy-700', 'text-neon-400');
                tab.classList.add('text-gray-400');
            });
            event.target.classList.remove('text-gray-400');
            event.target.classList.add('bg-navy-700', 'text-neon-400');
            renderSlots();
        }

        function renderSlots() {
            const container = document.getElementById('slots-container');
            container.innerHTML = '';
            const occupiedList = occupiedSlotsDatabase[selectedFieldId] || [];
            const filteredSlots = selectedPeriodFilter === 'all' 
                ? timeSlotsMaster 
                : timeSlotsMaster.filter(s => s.period === selectedPeriodFilter);

            filteredSlots.forEach(slot => {
                const isOccupied = occupiedList.includes(slot.time);
                const isSelected = selectedSlots.includes(slot.time);
                const btn = document.createElement('button');
                btn.type = 'button';
                
                if (isOccupied) {
                    btn.className = 'slot-btn w-full p-3 rounded-xl border bg-red-950/30 border-red-800/40 text-red-400/60 cursor-not-allowed text-xs font-semibold flex flex-col items-center justify-center gap-1';
                    btn.disabled = true;
                    btn.innerHTML = `<span>${slot.time}</span><span class="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-red-900/50 text-red-300">Terisi</span>`;
                } else if (isSelected) {
                    btn.className = 'slot-btn w-full p-3 rounded-xl border-2 border-neon-500 bg-neon-500 text-navy-900 font-extrabold text-xs flex flex-col items-center justify-center gap-1 shadow-neon-glow transform scale-105';
                    btn.onclick = () => toggleSlot(slot.time);
                    btn.innerHTML = `<span>${slot.time}</span><span class="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-navy-900 text-neon-400">Dipilih <i class="fa-solid fa-check"></i></span>`;
                } else {
                    btn.className = 'slot-btn w-full p-3 rounded-xl border border-white/10 bg-navy-900/80 hover:border-neon-500/60 hover:text-neon-400 text-gray-200 text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all';
                    btn.onclick = () => toggleSlot(slot.time);
                    btn.innerHTML = `<span>${slot.time}</span><span class="text-[9px] uppercase font-bold tracking-wider text-gray-400">Tersedia</span>`;
                }
                container.appendChild(btn);
            });
        }

        function toggleSlot(slotTime) {
            if (selectedSlots.includes(slotTime)) {
                selectedSlots = selectedSlots.filter(s => s !== slotTime);
            } else {
                selectedSlots.push(slotTime);
            }
            selectedSlots.sort();
            renderSlots();
            calculateTotal();
        }

        function calculateTotal() {
            const currentField = fieldsData.find(f => f.id === selectedFieldId);
            const dateVal = document.getElementById('booking-date').value || 'Belum dipilih';

            document.getElementById('summary-field-name').textContent = currentField.name;
            document.getElementById('summary-field-rate').textContent = `Rp ${parseInt(currentField.rate).toLocaleString('id-ID')} / jam`;
            document.getElementById('summary-date').textContent = dateVal;
            document.getElementById('summary-slots-count').textContent = `${selectedSlots.length} Jam`;

            const slotsListContainer = document.getElementById('summary-slots-list');
            slotsListContainer.innerHTML = '';
            if (selectedSlots.length === 0) {
                slotsListContainer.innerHTML = '<span class="text-[11px] text-gray-400 italic">Belum ada slot jam dipilih</span>';
            } else {
                selectedSlots.forEach(slot => {
                    const badge = document.createElement('span');
                    badge.className = 'text-[11px] font-bold px-2 py-0.5 rounded-md bg-neon-500/20 text-neon-400 border border-neon-500/30';
                    badge.textContent = slot;
                    slotsListContainer.appendChild(badge);
                });
            }

            const hasReferee = document.getElementById('extra-referee').checked;
            const hasBalls = document.getElementById('extra-balls').checked;
            const refereeCost = hasReferee ? (50000 * selectedSlots.length) : 0;
            const ballsCost = hasBalls ? 20000 : 0;

            const extrasRow = document.getElementById('summary-extras-row');
            if (hasReferee || hasBalls) {
                extrasRow.classList.remove('hidden');
                document.getElementById('summary-referee-cost').textContent = `Rp ${refereeCost.toLocaleString('id-ID')}`;
                document.getElementById('summary-balls-cost').textContent = `Rp ${ballsCost.toLocaleString('id-ID')}`;
            } else {
                extrasRow.classList.add('hidden');
            }

            const baseCost = currentField.rate * selectedSlots.length;
            const grandTotal = baseCost + refereeCost + ballsCost;
            document.getElementById('summary-total-price').textContent = `Rp ${grandTotal.toLocaleString('id-ID')}`;
        }

        function submitBooking() {
            const name = document.getElementById('cust-name').value.trim();
            const phone = document.getElementById('cust-phone').value.trim();
            const team = document.getElementById('cust-team').value.trim() || '-';
            const date = document.getElementById('booking-date').value;
            const currentField = fieldsData.find(f => f.id === selectedFieldId);

            if (selectedSlots.length === 0) {
                showToast('Harap pilih minimal 1 slot jam bermain!', 'error');
                return;
            }
            if (!name) {
                showToast('Mohon isi nama lengkap pemesan!', 'error');
                document.getElementById('cust-name').focus();
                return;
            }
            if (!phone) {
                showToast('Mohon isi nomor telepon/WhatsApp!', 'error');
                document.getElementById('cust-phone').focus();
                return;
            }

            const hasReferee = document.getElementById('extra-referee').checked;
            const hasBalls = document.getElementById('extra-balls').checked;
            const refereeCost = hasReferee ? (50000 * selectedSlots.length) : 0;
            const ballsCost = hasBalls ? 20000 : 0;
            const totalAmount = (currentField.rate * selectedSlots.length) + refereeCost + ballsCost;

            const formData = new FormData();
            formData.append('action', 'store');
            formData.append('field_id', selectedFieldId);
            formData.append('name', name);
            formData.append('team', team);
            formData.append('date', date);
            formData.append('total', totalAmount);
            selectedSlots.forEach(slot => formData.append('slots[]', slot));

            fetch('index.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(response => {
                if(response.success) {
                    const newBooking = response.data;
                    activeBookings.unshift(newBooking);
                    if (!occupiedSlotsDatabase[selectedFieldId]) {
                        occupiedSlotsDatabase[selectedFieldId] = [];
                    }
                    occupiedSlotsDatabase[selectedFieldId].push(...selectedSlots);

                    document.getElementById('rec-code').textContent = newBooking.code;
                    document.getElementById('rec-name').textContent = name;
                    document.getElementById('rec-team').textContent = team;
                    document.getElementById('rec-field').textContent = currentField.name;
                    document.getElementById('rec-date').textContent = date;
                    document.getElementById('rec-slots').textContent = selectedSlots.join(', ');
                    document.getElementById('rec-total').textContent = `Rp ${totalAmount.toLocaleString('id-ID')}`;

                    selectedSlots = [];
                    document.getElementById('cust-name').value = '';
                    document.getElementById('cust-phone').value = '';
                    document.getElementById('cust-team').value = '';
                    document.getElementById('extra-referee').checked = false;
                    document.getElementById('extra-balls').checked = false;

                    renderSlots();
                    calculateTotal();
                    renderHistoryTable('all');

                    openModal();
                    triggerConfetti();
                } else {
                    showToast('Gagal menyimpan reservasi ke database.', 'error');
                }
            });
        }

        function openModal() {
            const modal = document.getElementById('booking-modal');
            const content = document.getElementById('modal-content');
            modal.classList.remove('hidden');
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                content.classList.remove('scale-95');
                content.classList.add('scale-100');
            }, 10);
        }

        function closeModal() {
            const modal = document.getElementById('booking-modal');
            const content = document.getElementById('modal-content');
            modal.classList.add('opacity-0');
            content.classList.remove('scale-100');
            content.classList.add('scale-95');
            setTimeout(() => modal.classList.add('hidden'), 300);
        }

        function renderHistoryTable(filter) {
            const tbody = document.getElementById('booking-history-rows');
            tbody.innerHTML = '';
            const filtered = filter === 'all' ? activeBookings : activeBookings.filter(b => b.status === filter);

            if (filtered.length === 0) {
                tbody.innerHTML = `<tr><td colspan="7" class="p-6 text-center text-gray-500 italic">Tidak ada riwayat reservasi.</td></tr>`;
                return;
            }

            filtered.forEach(b => {
                const tr = document.createElement('tr');
                tr.className = 'hover:bg-navy-800/50 transition-colors';
                const statusBadge = b.status === 'confirmed' 
                    ? '<span class="bg-neon-500/20 text-neon-400 font-bold px-2.5 py-1 rounded-full text-[11px] border border-neon-500/30">Terkonfirmasi</span>'
                    : '<span class="bg-blue-500/20 text-blue-400 font-bold px-2.5 py-1 rounded-full text-[11px] border border-blue-500/30">Selesai</span>';

                let actionButtonHtml = '<span class="text-gray-500 text-[11px] italic"></span>';
                if (isAdminLoggedIn) {
                    actionButtonHtml = `<button onclick="cancelBooking('${b.code}')" class="text-red-400 hover:text-red-300 font-bold text-xs bg-red-950/40 hover:bg-red-900/60 px-3 py-1.5 rounded-lg border border-red-800/40 transition-all">Batal</button>`;
                }

                tr.innerHTML = `
                    <td class="p-4 font-mono font-bold text-neon-400">${b.code}</td>
                    <td class="p-4"><span class="font-bold text-white block">${b.name}</span><span class="text-[11px] text-gray-400">${b.team}</span></td>
                    <td class="p-4 font-semibold text-gray-200">${b.field_name || b.field}</td>
                    <td class="p-4"><span class="text-gray-200 block font-medium">${b.date}</span><span class="text-[11px] text-neon-400 font-mono">${Array.isArray(b.slots) ? b.slots.join(', ') : b.slots}</span></td>
                    <td class="p-4 font-bold text-white">Rp ${parseInt(b.total).toLocaleString('id-ID')}</td>
                    <td class="p-4">${statusBadge}</td>
                    <td class="p-4 text-center">${actionButtonHtml}</td>
                `;
                tbody.appendChild(tr);
            });
        }

        function filterHistory(type) {
            document.querySelectorAll('.hist-filter').forEach(btn => {
                btn.classList.remove('bg-navy-700', 'text-neon-400');
                btn.classList.add('text-gray-400');
            });
            event.target.classList.remove('text-gray-400');
            event.target.classList.add('bg-navy-700', 'text-neon-400');
            renderHistoryTable(type);
        }

        function cancelBooking(code) {
            if (!isAdminLoggedIn) {
                showToast('Anda harus login sebagai Admin untuk membatalkan pesanan!', 'error');
                return;
            }

            const formData = new FormData();
            formData.append('action', 'cancel');
            formData.append('code', code);

            fetch('index.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(response => {
                if(response.success) {
                    activeBookings = activeBookings.filter(b => b.code !== code);
                    renderHistoryTable('all');
                    showToast(`Pesanan ${code} berhasil dibatalkan.`, 'info');
                } else {
                    showToast('Gagal membatalkan pesanan.', 'error');
                }
            });
        }

        function showToast(message, type = 'success') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            const bgColor = type === 'error' ? 'bg-red-900 border-red-500' : 'bg-navy-800 border-neon-500';
            const icon = type === 'error' ? 'fa-circle-exclamation text-red-400' : 'fa-circle-check text-neon-400';

            toast.className = `${bgColor} border text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 transition-all duration-300 transform translate-y-5 opacity-0 pointer-events-auto`;
            toast.innerHTML = `<i class="fa-solid ${icon} text-base"></i><span>${message}</span>`;
            container.appendChild(toast);
            setTimeout(() => toast.classList.remove('translate-y-5', 'opacity-0'), 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-2');
                setTimeout(() => toast.remove(), 300);
            }, 3500);
        }

        function triggerConfetti() {
            const canvas = document.getElementById('confetti-canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            const particles = [];
            const colors = ['#00ff87', '#38ef7d', '#ffffff', '#2a365c'];

            for (let i = 0; i < 80; i++) {
                particles.push({
                    x: canvas.width / 2, y: canvas.height / 2,
                    vx: (Math.random() - 0.5) * 12, vy: (Math.random() - 0.7) * 12,
                    size: Math.random() * 6 + 4,
                    color: colors[Math.floor(Math.random() * colors.length)],
                    life: 100
                });
            }

            function animateConfetti() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                let alive = false;
                particles.forEach(p => {
                    if (p.life > 0) {
                        alive = true;
                        p.x += p.vx;
                        p.y += p.vy;
                        p.vy += 0.2;
                        p.life--;
                        ctx.fillStyle = p.color;
                        ctx.beginPath();
                        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                        ctx.fill();
                    }
                });
                if (alive) requestAnimationFrame(animateConfetti);
                else ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
            animateConfetti();
        }
    </script>
</body>
</html>