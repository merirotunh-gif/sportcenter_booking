<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - SportCenter Booking</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        navy: { 900: '#070c1a', 800: '#0b132b', 700: '#1c2541', 600: '#2a365c' },
                        neon: { 400: '#38ef7d', 500: '#00ff87', 600: '#00cc6a' }
                    },
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    boxShadow: { 'neon-glow': '0 0 20px rgba(0, 255, 135, 0.35)' }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #070c1a; color: #f1f5f9; }
        .glass-card { background: rgba(28, 37, 65, 0.75); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.08); }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 selection:bg-neon-500 selection:text-navy-900">
    <div class="glass-card max-w-md w-full rounded-3xl p-8 border border-neon-500/30 shadow-neon-glow space-y-6">
        <div class="text-center space-y-2">
            <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-neon-500 to-neon-400 flex items-center justify-center text-navy-900 font-extrabold text-2xl shadow-neon-glow mx-auto">
                <i class="fa-solid fa-lock text-navy-900"></i>
            </div>
            <h1 class="text-2xl font-black text-white">ADMIN LOGIN</h1>
            <p class="text-xs text-gray-400">Masuk untuk mengelola sistem reservasi SportCenter</p>
        </div>

        <?php if(isset($error)): ?>
            <div class="bg-red-950/60 border border-red-500/50 text-red-300 text-xs p-3 rounded-xl text-center">
                <i class="fa-solid fa-circle-exclamation mr-1"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form action="index.php?action=login" method="POST" class="space-y-4">
            <div>
                <label class="block text-xs font-medium text-gray-400 mb-1">Username Admin</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-4 text-neon-500"><i class="fa-solid fa-user"></i></span>
                    <input type="text" name="username" required placeholder="admin" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-neon-500">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-400 mb-1">Password</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-4 text-neon-500"><i class="fa-solid fa-key"></i></span>
                    <input type="password" name="password" required placeholder="••••••••" class="w-full bg-navy-900 border border-white/20 text-white rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-neon-500">
                </div>
            </div>
            <button type="submit" class="w-full bg-neon-500 hover:bg-neon-400 text-navy-900 font-extrabold py-3.5 rounded-xl text-sm transition-all shadow-neon-glow flex items-center justify-center gap-2">
                <i class="fa-solid fa-right-to-bracket"></i> Masuk Dashboard
            </button>
        </form>

        <div class="text-center pt-2 border-t border-white/10">
            <a href="index.php" class="text-xs text-gray-400 hover:text-neon-400 transition-colors">
                &larr; Kembali ke Beranda Pengunjung
            </a>
        </div>
        
        <div class="bg-navy-900/50 p-3 rounded-xl text-[11px] text-gray-400 text-center font-mono">
            Default Login: <span class="text-neon-400 font-bold">admin</span> / <span class="text-neon-400 font-bold">admin123</span>
        </div>
    </div>
</body>
</html>